import { useEffect, useRef } from "react";

// Pure generative canvas — no video needed.
// Renders: floating particles + animated grid + red orb pulse + Chinese character watermarks
export function HeroCanvas({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let t = 0;

    // ── Particles ──────────────────────────────────────────
    type Particle = {
      x: number; y: number;
      vx: number; vy: number;
      r: number; a: number;
      type: "red" | "cream" | "gold";
      pulse: number;
    };

    const PARTICLE_COUNT = 80;
    let particles: Particle[] = [];

    const initParticles = (W: number, H: number) => {
      particles = Array.from({ length: PARTICLE_COUNT }, () => ({
        x:     Math.random() * W,
        y:     Math.random() * H,
        vx:    (Math.random() - 0.5) * 0.35,
        vy:    (Math.random() - 0.5) * 0.35,
        r:     Math.random() * 1.8 + 0.4,
        a:     Math.random() * 0.55 + 0.15,
        type:  (["red", "cream", "gold"] as const)[Math.floor(Math.random() * 3)],
        pulse: Math.random() * Math.PI * 2,
      }));
    };

    // ── Chinese characters watermark ────────────────────────
    const CHARS = ["中", "国", "进", "出", "口", "贸", "易", "货", "钱", "商"];
    type Ghost = { char: string; x: number; y: number; size: number; a: number; va: number };
    let ghosts: Ghost[] = [];
    const initGhosts = (W: number, H: number) => {
      ghosts = Array.from({ length: 14 }, () => ({
        char: CHARS[Math.floor(Math.random() * CHARS.length)],
        x: Math.random() * W,
        y: Math.random() * H,
        size: Math.random() * 80 + 40,
        a: Math.random() * 0.04 + 0.01,
        va: (Math.random() - 0.5) * 0.0003,
      }));
    };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const W   = window.innerWidth;
      const H   = window.innerHeight;
      canvas.width  = W * dpr;
      canvas.height = H * dpr;
      canvas.style.width  = W + "px";
      canvas.style.height = H + "px";
      ctx.scale(dpr, dpr);
      initParticles(W, H);
      initGhosts(W, H);
    };
    resize();
    window.addEventListener("resize", resize, { passive: true });

    const draw = () => {
      const W = canvas.width  / Math.min(window.devicePixelRatio || 1, 2);
      const H = canvas.height / Math.min(window.devicePixelRatio || 1, 2);
      t += 0.008;

      ctx.clearRect(0, 0, W, H);

      // ── Base gradient ──────────────────────────────────────
      const bg = ctx.createRadialGradient(W * 0.5, H * 0.45, 0, W * 0.5, H * 0.45, W * 0.85);
      bg.addColorStop(0,   "rgba(30,8,8,1)");
      bg.addColorStop(0.5, "rgba(10,4,4,1)");
      bg.addColorStop(1,   "rgba(6,4,4,1)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // ── Animated grid ─────────────────────────────────────
      const GRID  = 72;
      const shift = (t * 12) % GRID;
      ctx.save();
      ctx.strokeStyle = "rgba(220,200,180,0.04)";
      ctx.lineWidth   = 0.5;
      for (let x = -GRID + shift; x < W + GRID; x += GRID) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      }
      for (let y = -GRID + shift; y < H + GRID; y += GRID) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      }
      ctx.restore();

      // ── Red orb (breathing) ───────────────────────────────
      const ox = W * 0.5 + Math.sin(t * 0.4) * W * 0.06;
      const oy = H * 0.42 + Math.cos(t * 0.3) * H * 0.04;
      const or = (Math.sin(t * 0.6) * 0.15 + 1) * Math.min(W, H) * 0.38;
      const orb = ctx.createRadialGradient(ox, oy, 0, ox, oy, or);
      orb.addColorStop(0,   "rgba(180,20,20,0.18)");
      orb.addColorStop(0.4, "rgba(140,15,15,0.08)");
      orb.addColorStop(1,   "rgba(100,10,10,0)");
      ctx.fillStyle = orb;
      ctx.fillRect(0, 0, W, H);

      // Secondary gold orb
      const o2x = W * 0.7 + Math.cos(t * 0.5) * W * 0.08;
      const o2y = H * 0.6 + Math.sin(t * 0.4) * H * 0.06;
      const o2 = ctx.createRadialGradient(o2x, o2y, 0, o2x, o2y, Math.min(W, H) * 0.25);
      o2.addColorStop(0,   "rgba(150,100,30,0.07)");
      o2.addColorStop(1,   "rgba(150,100,30,0)");
      ctx.fillStyle = o2;
      ctx.fillRect(0, 0, W, H);

      // ── Chinese character ghosts ───────────────────────────
      ctx.save();
      ctx.fontKerning = "none";
      for (const g of ghosts) {
        g.a  += g.va;
        if (g.a > 0.055) g.va = -Math.abs(g.va);
        if (g.a < 0.008) g.va =  Math.abs(g.va);
        ctx.globalAlpha = g.a;
        ctx.fillStyle   = "rgba(235,215,185,1)";
        ctx.font        = `${g.size}px 'Cormorant Garamond', Georgia, serif`;
        ctx.fillText(g.char, g.x, g.y);
      }
      ctx.globalAlpha = 1;
      ctx.restore();

      // ── Particles ─────────────────────────────────────────
      for (const p of particles) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
        if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;

        const pulsed = p.a * (0.7 + 0.3 * Math.sin(t * 2 + p.pulse));
        ctx.globalAlpha = pulsed;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle =
          p.type === "red"   ? "rgba(200,40,40,1)"  :
          p.type === "gold"  ? "rgba(200,160,60,1)" :
                               "rgba(235,215,190,1)";
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // ── Vignette overlay ──────────────────────────────────
      const vig = ctx.createRadialGradient(W/2, H/2, H*0.2, W/2, H/2, H*0.85);
      vig.addColorStop(0,   "rgba(0,0,0,0)");
      vig.addColorStop(1,   "rgba(0,0,0,0.72)");
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, W, H);

      // Bottom fade to background
      const fade = ctx.createLinearGradient(0, H * 0.55, 0, H);
      fade.addColorStop(0, "rgba(6,4,4,0)");
      fade.addColorStop(1, "rgba(6,4,4,1)");
      ctx.fillStyle = fade;
      ctx.fillRect(0, 0, W, H);

      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      aria-hidden="true"
      style={{ transform: "translateZ(0)", willChange: "transform" }}
    />
  );
}
