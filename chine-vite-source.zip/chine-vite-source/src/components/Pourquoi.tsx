import { motion } from "motion/react";
import { MapPin, Clock, Star, Lock } from "lucide-react";
import { BlurText } from "@/components/BlurText";
import { REASONS } from "@/lib/constants";

const ICONS: Record<string, React.ElementType> = { MapPin, Clock, Star, Lock };

export function Pourquoi() {
  return (
    <section className="relative py-28 md:py-40 border-t border-border/40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)]">

        {/* Header — centered */}
        <div className="text-center mb-16">
          <motion.span
            className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/75 font-body inline-block mb-5"
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5 }}
          >
            Pourquoi nous
          </motion.span>
          <BlurText
            text="Pas une formation. Un partenariat."
            as="h2"
            className="font-display uppercase text-4xl md:text-6xl leading-[0.9] tracking-tight max-w-[18ch] mx-auto"
            delay={0.07}
          />
          <motion.p
            className="mt-5 font-body text-foreground/60 text-base max-w-lg mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 16, filter: "blur(8px)" }}
            whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
          >
            On mise sur tes résultats, pas sur ta carte bleue. C'est pour ça qu'on fait un appel découverte avant de te proposer quoi que ce soit.
          </motion.p>
        </div>

        {/* 4-col grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {REASONS.map((reason, i) => {
            const Icon = ICONS[reason.icon] ?? MapPin;
            return (
              <motion.div
                key={reason.title}
                className="liquid-glass rounded-2xl p-7 flex flex-col gap-5 min-h-[260px]"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.65,
                  ease: [0.22, 1, 0.36, 1],
                  delay: i * 0.08,
                }}
              >
                <div className="liquid-glass-strong rounded-full w-11 h-11 flex items-center justify-center">
                  <Icon className="size-5 text-foreground" />
                </div>
                <h3 className="font-display uppercase text-xl tracking-tight">
                  {reason.title}
                </h3>
                <p className="font-body text-sm text-foreground/60 leading-relaxed">
                  {reason.body}
                </p>
                <div className="mt-auto h-px w-10 bg-gradient-to-r from-primary to-transparent" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
