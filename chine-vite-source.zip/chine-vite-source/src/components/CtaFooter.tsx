import { motion } from "motion/react";
import { ArrowUpRight, Phone } from "lucide-react";
import { BlurText } from "@/components/BlurText";
import { Button } from "@/components/ui/button";
import {
  CTA_HEADLINE, CTA_SUB, CTA_LABEL, CTA_HREF,
  FOOTER_LINKS, COPYRIGHT, BRAND_NAME,
} from "@/lib/constants";

export function CtaFooter() {
  return (
    <section
      id="cta"
      className="relative min-h-[100vh] flex flex-col items-center justify-center overflow-hidden border-t border-border/40"
    >
      {/* Atmospheric background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/15 to-background" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_50%_at_50%_50%,rgba(180,30,30,0.12),transparent)]" />

      {/* Top + bottom fades */}
      <div className="absolute top-0 inset-x-0 h-[220px] gradient-fade-t pointer-events-none" />
      <div className="absolute bottom-0 inset-x-0 h-[220px] gradient-fade-b pointer-events-none" />

      {/* Grid texture */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(245,238,225,1) 1px, transparent 1px), linear-gradient(90deg, rgba(245,238,225,1) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 py-32 w-full">

        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
        >
          <span className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/75 font-body inline-block mb-8">
            Prêt à commencer ?
          </span>
        </motion.div>

        {/* Headline */}
        <BlurText
          text={CTA_HEADLINE}
          as="h2"
          className="font-display italic text-[clamp(56px,10vw,180px)] leading-[0.88] tracking-[-0.02em] text-center max-w-[16ch]"
          delay={0.09}
          startDelay={0.1}
        />

        {/* Sub */}
        <motion.p
          className="mt-8 font-body text-base md:text-lg text-foreground/65 max-w-xl text-center leading-relaxed"
          initial={{ opacity: 0, y: 16, filter: "blur(8px)" }}
          whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.4 }}
        >
          {CTA_SUB}
        </motion.p>

        {/* Buttons */}
        <motion.div
          className="mt-10 flex items-center gap-3 flex-wrap justify-center"
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.55 }}
        >
          <Button variant="hero" asChild>
            <a href={CTA_HREF} className="flex items-center gap-2">
              <Phone className="size-4" />
              {CTA_LABEL}
            </a>
          </Button>
          <Button variant="heroGlass" asChild>
            <a href="#services">
              Voir l'accompagnement
              <ArrowUpRight className="ml-1 size-4" />
            </a>
          </Button>
        </motion.div>

        {/* Reassurances */}
        <motion.div
          className="mt-10 flex items-center gap-6 flex-wrap justify-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.7 }}
        >
          {[
            "Appel 100% gratuit",
            "Sans engagement",
            "Réponse sous 24h",
          ].map((item) => (
            <span key={item} className="font-body text-xs text-foreground/40 uppercase tracking-wide">
              {item}
            </span>
          ))}
        </motion.div>
      </div>

      {/* Footer bar */}
      <div className="relative z-10 w-full border-t border-border/40 mt-auto">
        <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)] py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center">
              <span className="font-display text-primary-foreground text-xs font-bold leading-none">中</span>
            </div>
            <span className="font-body text-xs text-foreground/40">{COPYRIGHT}</span>
          </div>
          <nav className="flex items-center gap-6" aria-label="Liens du pied de page">
            {FOOTER_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="font-body text-xs text-foreground/40 hover:text-foreground/70 transition-colors focus-visible:ring-2 focus-visible:ring-ring rounded"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="hidden md:block">
            <span className="font-body text-xs text-foreground/25 italic font-display">
              {BRAND_NAME}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
