import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BRAND_NAME, NAV_ITEMS, CTA_LABEL, CTA_HREF } from "@/lib/constants";

export function Navbar() {
  const [scrolled, setScrolled]   = useState(false);
  const [menuOpen, setMenuOpen]   = useState(false);
  const [activeHref, setActiveHref] = useState("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Track active section
  useEffect(() => {
    const ids = NAV_ITEMS.map((n) => n.href.replace("#", ""));
    const observers: IntersectionObserver[] = [];
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const io = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) setActiveHref(`#${id}`); },
        { threshold: 0.4 }
      );
      io.observe(el);
      observers.push(io);
    });
    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <>
      <motion.header
        className={`fixed z-50 left-1/2 -translate-x-1/2 w-[min(1200px,calc(100vw-32px))] transition-all duration-300 ${scrolled ? "top-2" : "top-4"}`}
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="liquid-glass rounded-full px-2 py-2 flex items-center justify-between gap-4">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2.5 pl-3">
            <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center">
              <span className="font-display text-primary-foreground text-sm font-bold leading-none">中</span>
            </div>
            <span className="font-display text-lg tracking-tight text-foreground font-semibold">
              {BRAND_NAME}
            </span>
          </a>

          {/* Center nav */}
          <nav className="hidden md:flex items-center gap-1" aria-label="Navigation principale">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className={`relative px-3.5 py-2 text-sm font-body transition-colors ${
                  activeHref === item.href
                    ? "text-foreground"
                    : "text-foreground/65 hover:text-foreground"
                }`}
              >
                {item.label}
                {activeHref === item.href && (
                  <span className="absolute bottom-0.5 left-1/2 -translate-x-1/2 h-1 w-1 rounded-full bg-primary" />
                )}
              </a>
            ))}
          </nav>

          {/* CTA */}
          <div className="flex items-center gap-2">
            <Button
              variant="heroSolid"
              size="sm"
              className="hidden md:inline-flex rounded-full px-5 py-2 text-sm"
              asChild
            >
              <a href={CTA_HREF}>
                {CTA_LABEL}
                <ArrowUpRight className="ml-1 size-4" />
              </a>
            </Button>
            {/* Mobile menu button */}
            <button
              className="md:hidden liquid-glass rounded-full p-2 text-foreground/80 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label={menuOpen ? "Fermer le menu" : "Ouvrir le menu"}
              aria-expanded={menuOpen}
            >
              {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile menu */}
      {menuOpen && (
        <motion.div
          className="fixed inset-0 z-40 liquid-glass-strong flex flex-col items-center justify-center gap-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="font-display text-4xl tracking-tight text-foreground/80 hover:text-foreground transition-colors uppercase"
              onClick={() => setMenuOpen(false)}
            >
              {item.label}
            </a>
          ))}
          <Button variant="hero" asChild>
            <a href={CTA_HREF} onClick={() => setMenuOpen(false)}>
              {CTA_LABEL} <ArrowUpRight className="ml-1 size-4" />
            </a>
          </Button>
        </motion.div>
      )}
    </>
  );
}
