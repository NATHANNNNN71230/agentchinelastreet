export const FRAMES_PATH = "/frames";
export const FRAME_COUNT = 120; // Update after running ffmpeg extraction
export const FRAME_EXT   = "jpg" as const;

export const BRAND_NAME    = "La Chine En Vrai";
export const BRAND_TAGLINE = "L'import depuis la Chine";

export const NAV_ITEMS = [
  { label: "Accompagnement", href: "#services" },
  { label: "Méthode",        href: "#process" },
  { label: "Témoignages",    href: "#testimonials" },
  { label: "FAQ",            href: "#faq" },
];

export const PARTNERS = [
  "Snapchat",
  "Alibaba",
  "1688.com",
  "Taobao",
  "Made-in-China",
  "Global Sources",
];

export const SERVICES = [
  {
    icon: "Map",
    title: "Sourcing Terrain",
    body: "Nos experts basés en Chine visitent physiquement les usines pour toi. Tu obtiens des devis réels, pas des prix catalogue.",
  },
  {
    icon: "Users",
    title: "Coaching 1-to-1",
    body: "Un expert dédié qui connaît ton marché, disponible pour répondre à toutes tes questions en temps réel.",
  },
  {
    icon: "ShieldCheck",
    title: "Anti-Arnaque",
    body: "Vérification des fournisseurs, audit qualité avant expédition, et conseils douaniers pour éviter les mauvaises surprises.",
  },
  {
    icon: "TrendingUp",
    title: "Trouver des Clients",
    body: "Méthodes éprouvées pour convertir tes abonnés Snapchat en clients payants, sans budget pub.",
  },
  {
    icon: "Globe",
    title: "Logistique Complète",
    body: "De l'entrepôt chinois à ta porte : fret maritime ou aérien, dédouanement, livraison last-mile.",
  },
  {
    icon: "Zap",
    title: "Résultats Rapides",
    body: "Premier fournisseur en 7 jours. Premiers clients en 3 semaines. Plan d'action dès le premier appel.",
  },
];

export const REASONS = [
  {
    icon: "MapPin",
    title: "Basés en Chine",
    body: "Nos équipes sont physiquement sur place à Shenzhen, Canton et Yiwu. Pas de formation théorique — du terrain réel.",
  },
  {
    icon: "Clock",
    title: "Résultats en 14 jours",
    body: "Notre méthode est calibrée pour te faire encaisser tes premières ventes rapidement, pas dans 6 mois.",
  },
  {
    icon: "Star",
    title: "97% de satisfaction",
    body: "Plus de 3 200 membres accompagnés avec un taux de satisfaction exceptionnel. Les chiffres parlent.",
  },
  {
    icon: "Lock",
    title: "Zéro risque",
    body: "Si tu suis le plan et tu n'as pas de résultat en 30 jours, on continue gratuitement jusqu'à ce que ça marche.",
  },
];

export const PROCESS_STEPS = [
  {
    n: "1",
    title: "Appel découverte",
    body: "30 minutes gratuites. On analyse ta situation, ton budget, tes objectifs. Tu repars avec un plan — même si on ne travaille pas ensemble.",
  },
  {
    n: "2",
    title: "Ton plan sur mesure",
    body: "On identifie ton produit, ton marché, tes fournisseurs cibles. Roadmap personnalisée, pas un PDF générique.",
  },
  {
    n: "3",
    title: "Sourcing & négociation",
    body: "Nos experts en Chine contactent les usines, négocient les prix, vérifient la qualité. Tu choisis le meilleur.",
  },
  {
    n: "4",
    title: "Tu encaisses",
    body: "Tes clients reçoivent leurs commandes. Tu gères depuis ton téléphone. On reste disponibles pour chaque problème.",
  },
];

export const STATS = [
  { value: "3200+", label: "Membres accompagnés" },
  { value: "97%",   label: "Taux de satisfaction" },
  { value: "14j",   label: "Premiers résultats" },
  { value: "8 ans", label: "Expérience terrain" },
];

export const TESTIMONIALS = [
  {
    quote: "En 3 semaines j'avais mon premier client. Le suivi 1-to-1 a tout changé — je pensais que c'était compliqué, c'est juste une question de méthode.",
    name: "Kévin M.",
    role: "19 ans — Étudiant à Lyon",
  },
  {
    quote: "J'avais zéro expérience en import. En 6 semaines, j'ai sourcé un produit, trouvé 2 clients et encaissé ma première commande. Ça paraît fou mais c'est vrai.",
    name: "Samir B.",
    role: "24 ans — Freelance à Paris",
  },
  {
    quote: "Ils m'ont guidé sur chaque étape de la négo fournisseur. Je commande maintenant à prix usine et mes marges ont triplé.",
    name: "Axel D.",
    role: "22 ans — Bordeaux",
  },
  {
    quote: "Ce qui m'a convaincu c'est qu'ils sont physiquement là-bas. Pas un coach YouTube — de vraies personnes qui connaissent les usines.",
    name: "Inès R.",
    role: "21 ans — Marseille",
  },
  {
    quote: "J'avais peur de me faire arnaquer sur Alibaba. Maintenant j'ai un fournisseur direct et je gagne 800€ par mois avec mon téléphone.",
    name: "Théo L.",
    role: "20 ans — Nantes",
  },
  {
    quote: "Le premier appel m'a suffi pour comprendre que c'était différent. Un vrai plan, pas des généralités. En 1 mois, mon business était lancé.",
    name: "Camille V.",
    role: "23 ans — Lille",
  },
];

export const FAQ_ITEMS = [
  {
    q: "Est-ce fait pour moi si j'ai zéro expérience en import ?",
    a: "Oui — c'est même pour ça qu'on existe. La majorité de nos membres avaient zéro expérience avant de rejoindre. Notre accompagnement est construit pour partir de zéro. Ce qu'on cherche chez toi : de la motivation et l'envie de passer à l'action. Le reste, on te l'enseigne.",
  },
  {
    q: "Et si ça ne marche pas pour moi ?",
    a: "On ne t'accepte pas dans le programme si on pense que tu n'es pas prêt — c'est pour ça qu'on fait un appel découverte avant. Si tu suis le plan et qu'il n'y a pas de résultat en 30 jours, on continue à t'accompagner gratuitement jusqu'à ce que tu en aies.",
  },
  {
    q: "En quoi c'est différent d'une formation classique ?",
    a: "Une formation, c'est des vidéos que tu regardes seul à 23h et que tu oublies. Nous, c'est un expert disponible pour répondre à TES questions sur TON business. On est physiquement en Chine — on connaît les fournisseurs, les arnaques, les raccourcis.",
  },
  {
    q: "Combien de temps avant de voir des résultats concrets ?",
    a: "La plupart de nos membres trouvent leur premier fournisseur qualifié en 7 à 10 jours. Les premiers clients arrivent entre la 2ème et la 4ème semaine. Ça demande du travail — mais les résultats sont mesurables rapidement.",
  },
  {
    q: "Quel est le vrai prix ? Y a-t-il des frais cachés ?",
    a: "L'accompagnement est entre 600 et 900€ selon la formule choisie lors de ton appel. Pas d'upsell, pas d'abonnement caché. Le premier appel de découverte est 100% gratuit, sans engagement, sans carte bleue.",
  },
  {
    q: "J'ai seulement Snapchat comme réseau. C'est suffisant ?",
    a: "C'est exactement notre spécialité. Nos méthodes sont construites autour de Snapchat et des réseaux sociaux mobiles. Tu n'as pas besoin d'un site, de pub payante, ni d'une marque établie pour commencer.",
  },
];

export const CTA_HEADLINE  = "C'est ton tour.";
export const CTA_SUB       = "Un appel gratuit. Un plan. Tes premières ventes.";
export const CTA_LABEL     = "Réserver mon appel gratuit";
export const CTA_HREF      = "#cta";

export const FOOTER_LINKS = [
  { label: "Mentions légales",     href: "/legal" },
  { label: "Politique de vie privée", href: "/privacy" },
  { label: "Contact",              href: "mailto:contact@lachineenvrai.com" },
  { label: "Snapchat",             href: "#" },
];

export const COPYRIGHT = "© 2025 La Chine En Vrai. Tous droits réservés.";
