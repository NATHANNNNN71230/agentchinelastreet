import { motion } from "motion/react";
import { Quote } from "lucide-react";
import { BlurText } from "@/components/BlurText";
import { TESTIMONIALS } from "@/lib/constants";

type Testi = { quote: string; name: string; role: string };

function TestiCard({ quote, name, role }: Testi) {
  return (
    <div className="liquid-glass rounded-2xl p-7 w-[340px] md:w-[400px] shrink-0 flex flex-col gap-5">
      <Quote className="size-5 text-primary/70" />
      <blockquote className="font-body text-foreground/85 italic leading-relaxed text-[15px] flex-1">
        &ldquo;{quote}&rdquo;
      </blockquote>
      <div className="mt-auto flex items-center gap-3">
        <div className="size-9 rounded-full bg-gradient-to-br from-primary/50 to-secondary/60 flex-shrink-0" />
        <div>
          <p className="font-body font-medium text-sm text-foreground">{name}</p>
          <p className="font-body text-xs text-foreground/50 uppercase tracking-wide">{role}</p>
        </div>
      </div>
    </div>
  );
}

const ROW_A = [...TESTIMONIALS, ...TESTIMONIALS];
const ROW_B = [
  ...TESTIMONIALS.slice(3),
  ...TESTIMONIALS.slice(0, 3),
  ...TESTIMONIALS.slice(3),
  ...TESTIMONIALS.slice(0, 3),
];

export function Testimonials() {
  return (
    <section id="testimonials" className="relative py-28 md:py-40 border-t border-border/40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)]">

        {/* Header */}
        <div className="mb-16">
          <motion.span
            className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/75 font-body inline-block mb-5"
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5 }}
          >
            Témoignages
          </motion.span>
          <BlurText
            text="Ils parlent mieux que nous."
            as="h2"
            className="font-display uppercase text-4xl md:text-6xl leading-[0.9] tracking-tight max-w-[18ch]"
            delay={0.07}
          />
        </div>
      </div>

      {/* Marquee — full width, outside container */}
      <div className="mt-4 flex flex-col gap-5 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)] group">
        {/* Row 1 — left */}
        <div className="flex gap-5 w-max animate-[marquee_28s_linear_infinite] group-hover:[animation-play-state:paused]">
          {ROW_A.map((t, i) => (
            <TestiCard key={i} {...t} />
          ))}
        </div>

        {/* Row 2 — right */}
        <div className="flex gap-5 w-max animate-[marquee-rev_32s_linear_infinite] group-hover:[animation-play-state:paused]">
          {ROW_B.map((t, i) => (
            <TestiCard key={i} {...t} />
          ))}
        </div>
      </div>
    </section>
  );
}
