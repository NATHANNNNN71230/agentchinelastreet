import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "motion/react";
import { STATS } from "@/lib/constants";

function AnimatedStat({ value }: { value: string }) {
  const ref    = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref as React.RefObject<Element>, { once: true, amount: 0.5 });
  const [display, setDisplay] = useState("0");

  useEffect(() => {
    if (!inView) return;
    // Extract numeric part and suffix
    const numStr  = value.replace(/[^0-9]/g, "");
    const suffix  = value.replace(/[0-9]/g, "");
    const numVal  = parseInt(numStr, 10);

    if (isNaN(numVal)) { setDisplay(value); return; }

    const duration = 1800;
    const steps    = 60;
    const inc      = numVal / steps;
    let   current  = 0;
    let   frame    = 0;

    const tick = () => {
      frame++;
      current = Math.min(current + inc, numVal);
      setDisplay(Math.floor(current).toLocaleString("fr-FR") + suffix);
      if (frame < steps) requestAnimationFrame(tick);
      else setDisplay(numVal.toLocaleString("fr-FR") + suffix);
    };
    requestAnimationFrame(tick);
  }, [inView, value]);

  return <span ref={ref}>{display}</span>;
}

export function Stats() {
  return (
    <section className="relative py-32 md:py-44 overflow-hidden border-t border-border/40">
      {/* Background gradient (no video needed — pure CSS atmosphere) */}
      <div className="absolute inset-0 bg-gradient-to-br from-secondary/20 via-background to-background" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_50%,rgba(180,30,30,0.08),transparent)]" />

      {/* Top + bottom fades */}
      <div className="absolute top-0 inset-x-0 h-[200px] gradient-fade-t pointer-events-none" />
      <div className="absolute bottom-0 inset-x-0 h-[200px] gradient-fade-b pointer-events-none" />

      {/* Inner card */}
      <div className="relative z-10 max-w-[var(--max)] mx-auto px-[var(--gutter)]">
        <motion.div
          className="liquid-glass rounded-3xl p-10 md:p-14"
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 relative">
            {STATS.map((stat, i) => (
              <div key={stat.label} className="relative flex flex-col items-start">
                {/* Separator */}
                {i > 0 && (
                  <div className="hidden md:block absolute -left-6 top-1/2 -translate-y-1/2 w-px h-12 bg-border" />
                )}
                <div className="font-display italic text-5xl md:text-6xl lg:text-7xl leading-none text-foreground">
                  <AnimatedStat value={stat.value} />
                </div>
                <p className="font-body text-sm text-foreground/55 mt-3 tracking-wide uppercase">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
