import { motion } from "motion/react";
import {
  Map, Users, ShieldCheck, TrendingUp, Globe, Zap, ArrowUpRight,
} from "lucide-react";
import { BlurText } from "@/components/BlurText";
import { SERVICES } from "@/lib/constants";
import { cn } from "@/lib/utils";

const ICONS: Record<string, React.ElementType> = {
  Map, Users, ShieldCheck, TrendingUp, Globe, Zap,
};

const CARD_CLASSES = [
  "md:row-span-2 md:col-span-1 p-8 min-h-[480px]",
  "md:col-span-1 p-6 min-h-[228px]",
  "md:col-span-1 p-6 min-h-[228px]",
  "md:col-span-2 p-7 min-h-[228px]",
  "md:col-span-1 p-6 min-h-[228px]",
  "md:col-span-3 p-7 min-h-[180px]",
];

export function ServicesBento() {
  return (
    <section id="services" className="relative py-28 md:py-40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)]">

        {/* Section header */}
        <div className="mb-14">
          <motion.span
            className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/75 font-body inline-block mb-5"
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5 }}
          >
            Ce qu'on fait
          </motion.span>
          <BlurText
            text="Tout ce qu'il faut. Sous un seul toit."
            as="h2"
            className="font-display uppercase text-4xl md:text-6xl lg:text-7xl leading-[0.92] tracking-[-0.02em] max-w-[22ch]"
            delay={0.07}
          />
          <motion.p
            className="mt-5 font-body text-foreground/60 text-base max-w-xl leading-relaxed"
            initial={{ opacity: 0, y: 16, filter: "blur(8px)" }}
            whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
          >
            De la recherche de fournisseurs à tes premières ventes — notre accompagnement couvre chaque étape du processus.
          </motion.p>
        </div>

        {/* Bento grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
          {SERVICES.map((service, idx) => {
            const Icon = ICONS[service.icon] ?? Zap;
            return (
              <motion.div
                key={service.title}
                className={cn(
                  "liquid-glass rounded-2xl relative overflow-hidden group flex flex-col",
                  CARD_CLASSES[idx]
                )}
                whileHover={{ y: -4 }}
                transition={{ type: "spring", stiffness: 260, damping: 26 }}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
              >
                {/* Icon */}
                <div className="liquid-glass-strong rounded-full w-11 h-11 flex items-center justify-center mb-5 flex-shrink-0">
                  <Icon className="size-5 text-foreground" />
                </div>

                {/* Text */}
                <h3 className="font-display uppercase text-2xl md:text-3xl leading-[0.95] tracking-tight mb-3 max-w-[18ch]">
                  {service.title}
                </h3>
                <p className="font-body text-sm text-foreground/60 max-w-[38ch] leading-relaxed">
                  {service.body}
                </p>

                {/* Accent line */}
                <div className="mt-auto pt-6">
                  <div className="h-px w-10 bg-gradient-to-r from-primary to-transparent" />
                </div>

                {/* Arrow */}
                <ArrowUpRight className="absolute top-6 right-6 size-5 text-foreground/25 group-hover:text-foreground/70 transition-colors duration-200" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
