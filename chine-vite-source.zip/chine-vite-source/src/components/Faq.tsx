import { motion } from "motion/react";
import { BlurText } from "@/components/BlurText";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FAQ_ITEMS, CTA_HREF } from "@/lib/constants";

export function Faq() {
  return (
    <section id="faq" className="relative py-28 md:py-40 border-t border-border/40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)]">
        <div className="grid grid-cols-1 md:grid-cols-[0.9fr_1.1fr] gap-16">

          {/* LEFT — sticky heading */}
          <div className="md:sticky md:top-24 md:self-start">
            <motion.span
              className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/75 font-body inline-block mb-5"
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.5 }}
            >
              Questions fréquentes
            </motion.span>
            <BlurText
              text="Questions fréquentes."
              as="h2"
              className="font-display uppercase text-4xl md:text-5xl lg:text-6xl leading-[0.9] tracking-tight mt-2"
              delay={0.07}
            />
            <motion.p
              className="mt-5 font-body text-foreground/60 text-sm leading-relaxed max-w-xs"
              initial={{ opacity: 0, y: 16, filter: "blur(8px)" }}
              whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
            >
              Tu as d'autres questions ? Notre équipe répond en moins de 24h.
            </motion.p>
            <motion.div
              className="mt-8"
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Button variant="heroGlass" asChild>
                <a href={CTA_HREF}>Nous contacter</a>
              </Button>
            </motion.div>
          </div>

          {/* RIGHT — accordion */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
          >
            <Accordion type="single" collapsible>
              {FAQ_ITEMS.map((item, i) => (
                <AccordionItem key={i} value={`item-${i}`}>
                  <AccordionTrigger className="font-display uppercase text-lg md:text-xl tracking-tight py-6 text-left hover:no-underline data-[state=open]:text-primary transition-colors">
                    {item.q}
                  </AccordionTrigger>
                  <AccordionContent className="font-body text-foreground/65 text-[15px] leading-relaxed pb-6 max-w-[60ch]">
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
