import { motion } from "motion/react";
import { BlurText } from "@/components/BlurText";
import { PROCESS_STEPS } from "@/lib/constants";

export function Process() {
  return (
    <section id="process" className="relative py-28 md:py-40 border-t border-border/40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)]">

        {/* Header */}
        <div className="text-center mb-16">
          <motion.span
            className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/75 font-body inline-block mb-5"
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5 }}
          >
            Comment ça marche
          </motion.span>
          <BlurText
            text="3 étapes. C'est tout."
            as="h2"
            className="font-display uppercase text-4xl md:text-6xl leading-[0.9] tracking-tight max-w-[18ch] mx-auto"
            delay={0.08}
          />
          <motion.p
            className="mt-5 font-body text-foreground/60 text-base max-w-md mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 16, filter: "blur(8px)" }}
            whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
          >
            On a supprimé tout ce qui était inutile. Ce qui reste ? Ce qui marche.
          </motion.p>
        </div>

        {/* Steps grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-0 relative">
          {PROCESS_STEPS.map((step, i) => (
            <motion.div
              key={step.n}
              className="relative px-6 md:px-10 py-10 md:py-14 flex flex-col gap-4 items-start border-b md:border-b-0 md:border-r border-border/30 last:border-none"
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.65,
                ease: [0.22, 1, 0.36, 1],
                delay: i * 0.1,
              }}
            >
              {/* Big number */}
              <span className="font-display text-[96px] md:text-[128px] leading-none text-primary/20 -mb-4 select-none">
                {step.n.padStart(2, "0")}
              </span>
              <h3 className="font-display uppercase text-2xl md:text-3xl tracking-tight">
                {step.title}
              </h3>
              <p className="font-body text-sm text-foreground/60 leading-relaxed max-w-[28ch]">
                {step.body}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA hint */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <a
            href="#cta"
            className="font-body text-sm text-foreground/50 hover:text-foreground transition-colors focus-visible:ring-2 focus-visible:ring-ring rounded"
          >
            Le premier appel est gratuit, sans engagement &rarr;
          </a>
        </motion.div>
      </div>
    </section>
  );
}
