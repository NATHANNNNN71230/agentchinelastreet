import { motion } from "motion/react";
import { ArrowUpRight, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BlurText } from "@/components/BlurText";
import { HeroCanvas } from "@/components/HeroCanvas";
import { BRAND_TAGLINE, PARTNERS, CTA_HREF } from "@/lib/constants";

export function Hero() {
  return (
    <section
      className="relative h-screen min-h-[600px] bg-background overflow-hidden"
      aria-label="Section principale"
    >
      <p className="sr-only">
        La Chine En Vrai — Accompagnement import/export depuis la Chine.
        Trouvez vos fournisseurs, générez vos premières ventes depuis votre téléphone.
      </p>

      {/* Generative canvas background */}
      <HeroCanvas className="absolute inset-0 w-full h-full z-0" />

      {/* Content layer */}
      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center text-center px-6">

        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="liquid-glass rounded-full px-1 py-1 inline-flex items-center gap-2">
            <span className="bg-primary text-primary-foreground rounded-full px-3 py-1 text-xs font-semibold font-body">
              Nouveau
            </span>
            <span className="pr-3 text-sm text-foreground/85 font-body">
              {BRAND_TAGLINE}
            </span>
          </div>
        </motion.div>

        {/* H1 — Cormorant Garamond display, generous leading */}
        <BlurText
          text="Gagne ta vie. Depuis ton téléphone."
          as="h1"
          className="mt-7 font-display uppercase text-[clamp(48px,7.5vw,124px)] leading-[1.0] tracking-[-0.015em] text-foreground max-w-[14ch]"
          delay={0.09}
          startDelay={0.18}
        />

        {/* Sub */}
        <motion.p
          initial={{ filter: "blur(10px)", opacity: 0, y: 18 }}
          animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
          transition={{ delay: 0.95, duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
          className="mt-6 font-body text-base md:text-[17px] text-foreground/68 max-w-[480px] leading-[1.7]"
        >
          Du sourcing Chine à tes premiers clients — un expert basé sur place
          t'accompagne à chaque étape.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.15, duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 flex items-center gap-3 flex-wrap justify-center"
        >
          <Button variant="hero" asChild>
            <a href={CTA_HREF} className="flex items-center gap-2">
              <Phone className="size-4" />
              Réserver mon appel gratuit
            </a>
          </Button>
          <Button variant="heroGlass" asChild>
            <a href="#process">
              Voir comment ça marche
              <ArrowUpRight className="ml-1.5 size-4" />
            </a>
          </Button>
        </motion.div>

        {/* Scroll cue */}
        <motion.div
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8, duration: 0.8 }}
        >
          <div
            className="w-px h-10 bg-gradient-to-b from-foreground/40 to-transparent"
            style={{ animation: "scueLine 2.2s ease-in-out infinite" }}
          />
          <span className="font-body text-[9px] tracking-[3px] uppercase text-foreground/30">
            Scroll
          </span>
        </motion.div>
      </div>

      {/* Partners strip — bottom */}
      <motion.div
        className="absolute bottom-0 inset-x-0 z-10 pb-20 flex flex-col items-center gap-3"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5, duration: 0.7 }}
      >
        <span className="liquid-glass rounded-full px-4 py-1.5 text-[11px] font-body text-foreground/65 tracking-wide">
          Plateformes compatibles
        </span>
        <div className="flex items-center gap-6 md:gap-12 flex-wrap justify-center px-6">
          {PARTNERS.map((p) => (
            <span
              key={p}
              className="font-display italic text-base md:text-xl text-foreground/45 tracking-tight"
            >
              {p}
            </span>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
